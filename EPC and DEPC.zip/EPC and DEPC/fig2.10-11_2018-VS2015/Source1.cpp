#in clude <iostream>
using namespace std;
int main() {
	cout << "hi" << endl;
	return 0;
}