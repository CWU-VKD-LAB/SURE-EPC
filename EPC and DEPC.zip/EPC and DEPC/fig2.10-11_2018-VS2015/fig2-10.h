#ifndef MAIN_H
#define MAIN_H
void main(int argc, char** argv);
void myDisplay(void);
void myMouse(int button, int state, int mouseX, int mouseY);
void myKeyboard(unsigned char theKey, int mouseX, int mouseY);
bool isSector(int sectorNum, int mouseX, int mouseY);
void DrawEllipse(int lineNum);
void elPer(int lineNum);
void DrawEllipseDown(int index, int lineNum);
void DrawEllipseLeft(int index, int lineNum);
void DrawEllipseRight(int index, int lineNum);
void DrawEllipseSide(int index, int lineNum, Direction dir);
void drawIntercept(int i, int j, int lineNum);
void myInit(void);
void readValues();
void scale(float scalar, int dimensionIndex);
void invert(int dimensionIndex);
void swap(int dimOne, int dimTwo);
void normalize();
void readEllipse();
#endif MAIN_H