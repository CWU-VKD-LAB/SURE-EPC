//File: ProjUtil.h
//Author: Rose McDonald

#ifndef PROJUTIL_H
#define PROJUTIL_H

#include <windows.h>
#include <math.h>
#include <gl/Gl.h>
#include <gl/Glu.h>
/*#include <iostream.h>*/
#include "glut.h"
//#include <cmath>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
//#include <cstdlib>
#include <stdlib.h>

#define MAX_DIM 20
#define ELLIPSE_FILE "EllipseDim.txt"
#define DATA_FILE "Iris.txt"
#define PI 3.14159265358979323846
#define DEG2RAD (PI/180.0) 
int screenWidth = 1500;
int screenHeight = 800;
double ar = 1;
GLdouble A, B, C, D;
GLsizei W, H;
int radX = 0; //to be filled by readEllipse
int radY = 0;
int cx = 0;
int cy = 0;
int isDynamic = 0;

enum PtDirection {Alternate, AllUp, AllDown};
PtDirection ptSetting = Alternate;

enum Direction {Up, Down, Left, Right};

float minVal = FLT_MAX;
float maxVal = -1;

#endif //PROJUTIL_H