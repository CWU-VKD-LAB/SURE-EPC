//File: ProjUtil.h
//Author: Rose McDonald

#ifndef PROJUTIL_H
#define PROJUTIL_H

#include <windows.h>
#include <math.h>
#include <gl/Gl.h>
#include <gl/Glu.h>
/*#include <iostream.h>*/
#include "glut.h"
//#include <cmath>
#include <iostream>
#include <fstream>
#include <string>

#include <map>
#include <ctime>
//#include <cstdlib>
#include <stdlib.h>
#include <algorithm>

#define PI 3.141592653589793238462643383
#define DEG2RAD (PI/180.0) 
#define MAX_DIM 4
#define ELLIPSE_FILE "EllipseDim.txt"
#define DATA_FILE "Skin_NonSkin.csv"
#define OUT_FILE "rectangle.csv"
#define INT_POINT_SIZE 4.0f
int screenWidth = 1500;
int screenHeight = 800;
double ar = 1;
GLdouble A, B, C, D;
GLsizei W, H;
int radX = 0; //to be filled by readEllipse
int radY = 0;
int cx = 0;
int cy = 0;

//for auto find rectangles
double coverageMin = 10;
double precisionMin = 90;
int sectionNumX = 50; //number of horizontal sections
int sectionNumY = 50; //number of vertical sections

#endif //PROJUTIL_H