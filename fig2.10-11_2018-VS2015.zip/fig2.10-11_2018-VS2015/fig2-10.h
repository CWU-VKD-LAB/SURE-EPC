#include  "ProjUtil.h"
#ifndef MAIN_H
#define MAIN_H
#include <vector>
void main(int argc, char** argv);
void myDisplay(void);
void myMouse(int button, int state, int mouseX, int mouseY);
void myKeyboard(unsigned char theKey, int mouseX, int mouseY);
bool isSector(int sectorNum, int mouseX, int mouseY);
void myInit(void);

void scale(float scalar, int dimensionIndex);
void invert(int dimensionIndex);
void swap(int dimOne, int dimTwo);
void normalize();
void writeRectangle(int rectNum);
void readValues();
void readEllipse();

void changeRectThreshold();
void pan(int direction);
void panUp();
void panDown();
void panLeft();
void panRight();

void zoomIn();
void zoomOut();

void toggleEllipse();
void toggleLines();
void togglePan();
#endif MAIN_H